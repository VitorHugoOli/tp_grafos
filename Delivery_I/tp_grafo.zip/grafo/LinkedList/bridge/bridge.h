#include "../grafoLinkedList.h"
#include "../conexo/conexo.h"

#ifndef TP_C_BRIDGE_H
#define TP_C_BRIDGE_H

int bridgeLinked(GrafoLinked grafo);

#endif //TP_C_BRIDGE_H
