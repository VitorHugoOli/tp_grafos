
#include "../grafoLinkedList.h"


void
BuscaProfundidade(GrafoLinked *grafo, int ini, int *visitado, int cont, listaAresta *explorado, listaAresta *retorno);

void BuscaProfundidade_grafo(GrafoLinked *grafo, int ini);
