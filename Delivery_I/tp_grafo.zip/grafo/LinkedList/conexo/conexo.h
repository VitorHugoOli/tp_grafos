#include "../grafoLinkedList.h"


#ifndef TP_C_CONEXO_H
#define TP_C_CONEXO_H


int ECCLinked(GrafoLinked grafo,int show_result);

void PCCLinked(GrafoLinked G, int verticeAnalise, int numGrupoConexo, int *groupConexoVertice);

#endif //TP_C_CONEXO_H
