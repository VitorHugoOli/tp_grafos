#include "../grafoMatriz.h"


#ifndef TP_C_CONEXO_H
#define TP_C_CONEXO_H


int ECC(GrafoMatriz G, int *groupConexoVertice);

void PCC(GrafoMatriz G, int verticeAnalise, int numGrupoConexo, int *groupConexoVertice);

#endif //TP_C_CONEXO_H
